import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 364.6953430176;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // productviewoST (15:1420)
        padding: EdgeInsets.fromLTRB(28*fem, 18.71*fem, 3.7*fem, 636*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xfffefefe),
          borderRadius: BorderRadius.circular(2.9175627232*fem),
          boxShadow: [
            BoxShadow(
              color: Color(0x3f000000),
              offset: Offset(3.8900835514*fem, 3.8900835514*fem),
              blurRadius: 4.8626046181*fem,
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // iosstatusbarblackyVM (15:1445)
              margin: EdgeInsets.fromLTRB(0.56*fem, 0*fem, 14.28*fem, 16.1*fem),
              width: double.infinity,
              height: 11.19*fem,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // leftsidefNB (I15:1445;3:84)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 225.61*fem, 0.4*fem),
                    width: 27.67*fem,
                    height: 10.79*fem,
                    child: Image.asset(
                      'assets/button-create-account-email-enter-your-email-this-is-a-status-text-password-create-a-password-this-is-a-status-text-confirm-password-confirm-your-password-this-is-a-status-text-check-this-box-if-you-agree-with-the-terms-create-account-have-an-account-login/images/left-side-JE7.png',
                      width: 27.67*fem,
                      height: 10.79*fem,
                    ),
                  ),
                  Container(
                    // rightsidevJ7 (I15:1445;3:70)
                    margin: EdgeInsets.fromLTRB(0*fem, 0.16*fem, 0*fem, 0*fem),
                    height: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // mobilesignalqR5 (I15:1445;3:79)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 4.89*fem, 0*fem),
                          width: 16.55*fem,
                          height: 10.38*fem,
                          child: Image.asset(
                            'assets/button-create-account-email-enter-your-email-this-is-a-status-text-password-create-a-password-this-is-a-status-text-confirm-password-confirm-your-password-this-is-a-status-text-check-this-box-if-you-agree-with-the-terms-create-account-have-an-account-login/images/mobile-signal-9Tq.png',
                            width: 16.55*fem,
                            height: 10.38*fem,
                          ),
                        ),
                        Container(
                          // wifiX31 (I15:1445;3:75)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 4.9*fem, 0.36*fem),
                          width: 14.87*fem,
                          height: 10.67*fem,
                          child: Image.asset(
                            'assets/button-create-account-email-enter-your-email-this-is-a-status-text-password-create-a-password-this-is-a-status-text-confirm-password-confirm-your-password-this-is-a-status-text-check-this-box-if-you-agree-with-the-terms-create-account-have-an-account-login/images/wifi-Z2j.png',
                            width: 14.87*fem,
                            height: 10.67*fem,
                          ),
                        ),
                        Container(
                          // batterykgT (I15:1445;3:71)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0*fem),
                          width: 23.68*fem,
                          height: 11.03*fem,
                          child: Image.asset(
                            'assets/button-create-account-email-enter-your-email-this-is-a-status-text-password-create-a-password-this-is-a-status-text-confirm-password-confirm-your-password-this-is-a-status-text-check-this-box-if-you-agree-with-the-terms-create-account-have-an-account-login/images/battery-wMM.png',
                            width: 23.68*fem,
                            height: 11.03*fem,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupgyqyrUb (7Z1HDar2fqrU1bfsAoGYqY)
              width: double.infinity,
              height: 132*fem,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // uia9h (15:1444)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 65*fem, 0*fem),
                    width: 150*fem,
                    height: 132*fem,
                    child: Image.asset(
                      'assets/button-create-account-email-enter-your-email-this-is-a-status-text-password-create-a-password-this-is-a-status-text-confirm-password-confirm-your-password-this-is-a-status-text-check-this-box-if-you-agree-with-the-terms-create-account-have-an-account-login/images/ui.png',
                      fit: BoxFit.cover,
                    ),
                  ),
                  Container(
                    // group1gTd (15:1464)
                    margin: EdgeInsets.fromLTRB(0*fem, 14*fem, 0*fem, 25*fem),
                    width: 118*fem,
                    height: double.infinity,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Container(
                          // autogroupryr4oHM (7Z1HWACk9AHK5knHt5RyR4)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 17*fem),
                          width: double.infinity,
                          height: 58*fem,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // autogrouphth86GT (7Z1HeVJCX3oaR3JvCVHtH8)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 0*fem),
                                height: double.infinity,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.end,
                                  children: [
                                    Container(
                                      // autogroupjcivbDD (7Z1HkuHBNPB96q6YHPJciv)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5*fem, 0*fem),
                                      width: 65*fem,
                                      height: 40*fem,
                                      child: Stack(
                                        children: [
                                          Positioned(
                                            // mrmehrajh1M (15:1438)
                                            left: 0*fem,
                                            top: 0*fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 65*fem,
                                                height: 24*fem,
                                                child: Text(
                                                  'Mr. Mehraj',
                                                  style: SafeGoogleFont (
                                                    'Poppins',
                                                    fontSize: 12*ffem,
                                                    fontWeight: FontWeight.w600,
                                                    height: 2*ffem/fem,
                                                    color: Color(0xff0f172a),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            // level3kEX (15:1439)
                                            left: 23*fem,
                                            top: 16*fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 41*fem,
                                                height: 24*fem,
                                                child: Text(
                                                  'Level 3',
                                                  style: SafeGoogleFont (
                                                    'Poppins',
                                                    fontSize: 12*ffem,
                                                    fontWeight: FontWeight.w400,
                                                    height: 2*ffem/fem,
                                                    color: Color(0xff000000),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    Container(
                                      // autogrouppzeaDto (7Z1Hqu8rPv66hbp7g2pZeA)
                                      margin: EdgeInsets.fromLTRB(19*fem, 0*fem, 0*fem, 0*fem),
                                      padding: EdgeInsets.fromLTRB(14.37*fem, 0*fem, 12.63*fem, 0*fem),
                                      height: 18*fem,
                                      decoration: BoxDecoration (
                                        color: Color(0xffec4242),
                                        borderRadius: BorderRadius.circular(18.5005970001*fem),
                                      ),
                                      child: Text(
                                        'PRO',
                                        textAlign: TextAlign.center,
                                        style: SafeGoogleFont (
                                          'Poppins',
                                          fontSize: 10.7108726501*ffem,
                                          fontWeight: FontWeight.w700,
                                          height: 1.5*ffem/fem,
                                          letterSpacing: 0.428434906*fem,
                                          color: Color(0xfffdf2f2),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                // ellipse23D1d (15:1437)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 6*fem),
                                width: 46*fem,
                                height: 46*fem,
                                decoration: BoxDecoration (
                                  borderRadius: BorderRadius.circular(23*fem),
                                  image: DecorationImage (
                                    fit: BoxFit.cover,
                                    image: AssetImage (
                                      'assets/button-create-account-email-enter-your-email-this-is-a-status-text-password-create-a-password-this-is-a-status-text-confirm-password-confirm-your-password-this-is-a-status-text-check-this-box-if-you-agree-with-the-terms-create-account-have-an-account-login/images/ellipse-23-bg-Xgf.png',
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // autogroupiohcfuD (7Z1J7Ph3BGX54PdoPEioHc)
                          margin: EdgeInsets.fromLTRB(48*fem, 0*fem, 10*fem, 0*fem),
                          width: double.infinity,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // image5mST (15:1435)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5*fem, 0*fem),
                                width: 18*fem,
                                height: 18*fem,
                                child: Image.asset(
                                  'assets/button-create-account-email-enter-your-email-this-is-a-status-text-password-create-a-password-this-is-a-status-text-confirm-password-confirm-your-password-this-is-a-status-text-check-this-box-if-you-agree-with-the-terms-create-account-have-an-account-login/images/image-5-y4w.png',
                                  fit: BoxFit.cover,
                                ),
                              ),
                              RichText(
                                // sylhet5T9 (15:1434)
                                text: TextSpan(
                                  style: SafeGoogleFont (
                                    'Poppins',
                                    fontSize: 12*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.5*ffem/fem,
                                    color: Color(0xff000000),
                                  ),
                                  children: [
                                    TextSpan(
                                      text: ' ',
                                      style: SafeGoogleFont (
                                        'Poppins',
                                        fontSize: 12*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.5*ffem/fem,
                                        color: Color(0xff000000),
                                      ),
                                    ),
                                    TextSpan(
                                      text: 'Sylhet',
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}