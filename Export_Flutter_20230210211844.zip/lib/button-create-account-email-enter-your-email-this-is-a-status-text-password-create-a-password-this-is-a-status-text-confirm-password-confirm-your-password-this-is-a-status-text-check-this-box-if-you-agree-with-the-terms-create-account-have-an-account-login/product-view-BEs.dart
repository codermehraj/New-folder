import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 364.6953430176;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // productviewbMV (21:1484)
        padding: EdgeInsets.fromLTRB(28*fem, 18.71*fem, 3.7*fem, 230*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xfffefefe),
          borderRadius: BorderRadius.circular(2.9175627232*fem),
          boxShadow: [
            BoxShadow(
              color: Color(0x3f000000),
              offset: Offset(3.8900835514*fem, 3.8900835514*fem),
              blurRadius: 4.8626046181*fem,
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // iosstatusbarblackiKd (21:1494)
              margin: EdgeInsets.fromLTRB(0.56*fem, 0*fem, 14.28*fem, 16.1*fem),
              width: double.infinity,
              height: 11.19*fem,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // leftsidebuD (I21:1494;3:84)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 225.61*fem, 0.4*fem),
                    width: 27.67*fem,
                    height: 10.79*fem,
                    child: Image.asset(
                      'assets/button-create-account-email-enter-your-email-this-is-a-status-text-password-create-a-password-this-is-a-status-text-confirm-password-confirm-your-password-this-is-a-status-text-check-this-box-if-you-agree-with-the-terms-create-account-have-an-account-login/images/left-side-zRh.png',
                      width: 27.67*fem,
                      height: 10.79*fem,
                    ),
                  ),
                  Container(
                    // rightsidegvf (I21:1494;3:70)
                    margin: EdgeInsets.fromLTRB(0*fem, 0.16*fem, 0*fem, 0*fem),
                    height: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // mobilesignal1CF (I21:1494;3:79)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 4.89*fem, 0*fem),
                          width: 16.55*fem,
                          height: 10.38*fem,
                          child: Image.asset(
                            'assets/button-create-account-email-enter-your-email-this-is-a-status-text-password-create-a-password-this-is-a-status-text-confirm-password-confirm-your-password-this-is-a-status-text-check-this-box-if-you-agree-with-the-terms-create-account-have-an-account-login/images/mobile-signal-YmH.png',
                            width: 16.55*fem,
                            height: 10.38*fem,
                          ),
                        ),
                        Container(
                          // wifit19 (I21:1494;3:75)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 4.9*fem, 0.36*fem),
                          width: 14.87*fem,
                          height: 10.67*fem,
                          child: Image.asset(
                            'assets/button-create-account-email-enter-your-email-this-is-a-status-text-password-create-a-password-this-is-a-status-text-confirm-password-confirm-your-password-this-is-a-status-text-check-this-box-if-you-agree-with-the-terms-create-account-have-an-account-login/images/wifi-ZPh.png',
                            width: 14.87*fem,
                            height: 10.67*fem,
                          ),
                        ),
                        Container(
                          // batteryz4B (I21:1494;3:71)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0*fem),
                          width: 23.68*fem,
                          height: 11.03*fem,
                          child: Image.asset(
                            'assets/button-create-account-email-enter-your-email-this-is-a-status-text-password-create-a-password-this-is-a-status-text-confirm-password-confirm-your-password-this-is-a-status-text-check-this-box-if-you-agree-with-the-terms-create-account-have-an-account-login/images/battery-1nj.png',
                            width: 23.68*fem,
                            height: 11.03*fem,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogrouphhe2oXR (7Z1KGGwG3kYEVuhHhAHHe2)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 112*fem),
              width: double.infinity,
              height: 132*fem,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // uiuaT (21:1493)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 65*fem, 0*fem),
                    width: 150*fem,
                    height: 132*fem,
                    child: Image.asset(
                      'assets/button-create-account-email-enter-your-email-this-is-a-status-text-password-create-a-password-this-is-a-status-text-confirm-password-confirm-your-password-this-is-a-status-text-check-this-box-if-you-agree-with-the-terms-create-account-have-an-account-login/images/ui-KMM.png',
                      fit: BoxFit.cover,
                    ),
                  ),
                  Container(
                    // group1RHu (21:1485)
                    margin: EdgeInsets.fromLTRB(0*fem, 14*fem, 0*fem, 25*fem),
                    width: 118*fem,
                    height: double.infinity,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Container(
                          // autogroupil6w8TD (7Z1KX6qtZS3k7PxN21iL6W)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 17*fem),
                          width: double.infinity,
                          height: 58*fem,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // autogroup52v8zkK (7Z1Kgr4em82cXhZ32g52V8)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 0*fem),
                                height: double.infinity,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.end,
                                  children: [
                                    Container(
                                      // autogroupjn3cUvP (7Z1Knm4Tuhi5f1fhaJjN3C)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5*fem, 0*fem),
                                      width: 65*fem,
                                      height: 40*fem,
                                      child: Stack(
                                        children: [
                                          Positioned(
                                            // mrmehrajNF5 (21:1489)
                                            left: 0*fem,
                                            top: 0*fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 65*fem,
                                                height: 24*fem,
                                                child: Text(
                                                  'Mr. Mehraj',
                                                  style: SafeGoogleFont (
                                                    'Poppins',
                                                    fontSize: 12*ffem,
                                                    fontWeight: FontWeight.w600,
                                                    height: 2*ffem/fem,
                                                    color: Color(0xff0f172a),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            // level3Lr7 (21:1490)
                                            left: 23*fem,
                                            top: 16*fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 41*fem,
                                                height: 24*fem,
                                                child: Text(
                                                  'Level 3',
                                                  style: SafeGoogleFont (
                                                    'Poppins',
                                                    fontSize: 12*ffem,
                                                    fontWeight: FontWeight.w400,
                                                    height: 2*ffem/fem,
                                                    color: Color(0xff000000),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    Container(
                                      // autogroup8wfcMmD (7Z1KsbFkNKPg4xVd7s8WfC)
                                      margin: EdgeInsets.fromLTRB(19*fem, 0*fem, 0*fem, 0*fem),
                                      padding: EdgeInsets.fromLTRB(14.37*fem, 0*fem, 12.63*fem, 0*fem),
                                      height: 18*fem,
                                      decoration: BoxDecoration (
                                        color: Color(0xffec4242),
                                        borderRadius: BorderRadius.circular(18.5005970001*fem),
                                      ),
                                      child: Text(
                                        'PRO',
                                        textAlign: TextAlign.center,
                                        style: SafeGoogleFont (
                                          'Poppins',
                                          fontSize: 10.7108726501*ffem,
                                          fontWeight: FontWeight.w700,
                                          height: 1.5*ffem/fem,
                                          letterSpacing: 0.428434906*fem,
                                          color: Color(0xfffdf2f2),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                // ellipse23mpw (21:1488)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 6*fem),
                                width: 46*fem,
                                height: 46*fem,
                                decoration: BoxDecoration (
                                  borderRadius: BorderRadius.circular(23*fem),
                                  image: DecorationImage (
                                    fit: BoxFit.cover,
                                    image: AssetImage (
                                      'assets/button-create-account-email-enter-your-email-this-is-a-status-text-password-create-a-password-this-is-a-status-text-confirm-password-confirm-your-password-this-is-a-status-text-check-this-box-if-you-agree-with-the-terms-create-account-have-an-account-login/images/ellipse-23-bg-M8F.png',
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // autogroupjy66oFq (7Z1LA5nGZBCqYhfDubjY66)
                          margin: EdgeInsets.fromLTRB(48*fem, 0*fem, 10*fem, 0*fem),
                          width: double.infinity,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // image5Wvw (21:1487)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5*fem, 0*fem),
                                width: 18*fem,
                                height: 18*fem,
                                child: Image.asset(
                                  'assets/button-create-account-email-enter-your-email-this-is-a-status-text-password-create-a-password-this-is-a-status-text-confirm-password-confirm-your-password-this-is-a-status-text-check-this-box-if-you-agree-with-the-terms-create-account-have-an-account-login/images/image-5-J6w.png',
                                  fit: BoxFit.cover,
                                ),
                              ),
                              RichText(
                                // sylhetD4f (21:1486)
                                text: TextSpan(
                                  style: SafeGoogleFont (
                                    'Poppins',
                                    fontSize: 12*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.5*ffem/fem,
                                    color: Color(0xff000000),
                                  ),
                                  children: [
                                    TextSpan(
                                      text: ' ',
                                      style: SafeGoogleFont (
                                        'Poppins',
                                        fontSize: 12*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.5*ffem/fem,
                                        color: Color(0xff000000),
                                      ),
                                    ),
                                    TextSpan(
                                      text: 'Sylhet',
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupux9pJEX (7Z1LTVSvs5nWYzDurKUx9p)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 22.5*fem, 112*fem),
              width: 310.5*fem,
              height: 133*fem,
              child: Stack(
                children: [
                  Positioned(
                    // addapaymentmethodbjR (22:1519)
                    left: 8.5*fem,
                    top: 0*fem,
                    child: Align(
                      child: SizedBox(
                        width: 302*fem,
                        height: 36*fem,
                        child: Text(
                          'Add a payment method',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Poppins',
                            fontSize: 23.3691749573*ffem,
                            fontWeight: FontWeight.w500,
                            height: 1.5*ffem/fem,
                            letterSpacing: 0.9347669983*fem,
                            color: Color(0xb2000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // frame1arF (22:1572)
                    left: 121*fem,
                    top: 0*fem,
                    child: Container(
                      width: 100*fem,
                      height: 100*fem,
                    ),
                  ),
                  Positioned(
                    // component3WE7 (21:1495)
                    left: 0*fem,
                    top: 84*fem,
                    child: Container(
                      width: 310*fem,
                      height: 49*fem,
                      decoration: BoxDecoration (
                        color: Color(0xffe60023),
                        borderRadius: BorderRadius.circular(30*fem),
                      ),
                      child: Center(
                        child: Text(
                          'Bkash',
                          style: SafeGoogleFont (
                            'Poppins',
                            fontSize: 14*ffem,
                            fontWeight: FontWeight.w600,
                            height: 1.5*ffem/fem,
                            color: Color(0xfff7f8fa),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // component5xM1 (22:1573)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 23*fem, 0*fem),
              padding: EdgeInsets.fromLTRB(105.5*fem, 14*fem, 104.5*fem, 14*fem),
              width: 310*fem,
              height: 49*fem,
              decoration: BoxDecoration (
                color: Color(0xffe60023),
                borderRadius: BorderRadius.circular(30*fem),
              ),
              child: Container(
                // autogroupawdgbes (7Z1MBZ5BApUFBUbB46aWDG)
                width: double.infinity,
                height: double.infinity,
                child: Center(
                  child: Text(
                    'Bank Account',
                    style: SafeGoogleFont (
                      'Poppins',
                      fontSize: 14*ffem,
                      fontWeight: FontWeight.w600,
                      height: 1.5*ffem/fem,
                      color: Color(0xfff7f8fa),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}