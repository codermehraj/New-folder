import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 310;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // component26bm (18:1480)
        padding: EdgeInsets.fromLTRB(106.5*fem, 14*fem, 106.5*fem, 14*fem),
        width: double.infinity,
        height: 49*fem,
        decoration: BoxDecoration (
          color: Color(0xffe60023),
          borderRadius: BorderRadius.circular(30*fem),
        ),
        child: Container(
          // autogroupeevemT1 (7Z1K1sBbxN78rVALz2eEve)
          width: double.infinity,
          height: double.infinity,
          child: Center(
            child: Text(
              'List a product',
              style: SafeGoogleFont (
                'Poppins',
                fontSize: 14*ffem,
                fontWeight: FontWeight.w600,
                height: 1.5*ffem/fem,
                color: Color(0xfff7f8fa),
              ),
            ),
          ),
        ),
      ),
          );
  }
}